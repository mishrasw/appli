package com.test;


import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(strict = false, features = "src/features/login.feature", format = { "pretty",
        "html:target/site/cucumber-pretty",
        "json:target/cucumber.json" }, tags = {})
public class RunCukesTest extends AbstractTestNGCucumberTests {
}
